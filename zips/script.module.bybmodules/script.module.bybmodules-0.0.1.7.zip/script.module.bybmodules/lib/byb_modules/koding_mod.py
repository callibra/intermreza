import koding



def Dolog(string):
	koding.dolog(string,line_info=True)