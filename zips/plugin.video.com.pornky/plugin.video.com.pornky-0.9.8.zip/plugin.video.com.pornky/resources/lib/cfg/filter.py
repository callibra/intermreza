# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, unicode_literals

from resources.lib.cfg.enum34 import Enum

class Filter(Enum):
    SUPPRESS = 0
    OFF = 1
    ONLY = 2
